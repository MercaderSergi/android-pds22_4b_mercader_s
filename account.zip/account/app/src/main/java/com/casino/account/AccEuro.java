package com.casino.account;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class AccEuro extends AppCompatActivity {
    ImageButton button_return_wallet;
    Button deposite;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*setContentView(R.layout.account_moves_euro);
        button_return_wallet = (ImageButton) findViewById(R.id.wallet_acc);
        button_return_wallet.setOnClickListener(v -> {
            Intent i = new Intent(v.getContext(), MainActivity.class);
            startActivity(i);
        });
        deposite = (Button) findViewById(R.id.button_deposite);
        deposite.setOnClickListener(v -> {
            Intent i = new Intent(v.getContext(), AccEuro.class);
            startActivity(i);
        });*/
    }

    /*
    public void deposite(View view)
    {
        Intent i = new Intent(view.getContext(), AccEuro.class);
        startActivity(i);
    }*/
}

/*
    ImageButton button_euro = (ImageButton) findViewById(R.id.euro_account);
        button_euro.setOnClickListener(v -> {
                Intent i = new Intent(v.getContext(), AccEuro.class);
        startActivity(i);
        });*/