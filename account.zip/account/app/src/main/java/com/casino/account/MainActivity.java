package com.casino.account;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
    ImageButton button_euro;
    ImageButton button_btc;
    ImageButton Button_eth;
    ImageButton button_usd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wallet);
        //link button
        button_euro = (ImageButton) findViewById(R.id.euro_account);
        button_btc = (ImageButton) findViewById(R.id.btc_account);
        Button_eth = (ImageButton) findViewById(R.id.eth_account);
        button_usd = (ImageButton) findViewById(R.id.usd_account);
        //envia al case el click
        button_euro.setOnClickListener(new MainActivity.listWalletMov());
        button_btc.setOnClickListener(new MainActivity.listWalletMov());
        Button_eth.setOnClickListener(new MainActivity.listWalletMov());
        button_usd.setOnClickListener(new MainActivity.listWalletMov());

    }
    private class listWalletMov implements View.OnClickListener
    {
        public void onClick(View v)
        {
            switch (v.getId())
            {
                case R.id.euro_account:
                {
                    setContentView(R.layout.account_moves_euro);
                    break;
                }
                case R.id.btc_account:
                {
                    setContentView(R.layout.acc_moves_btc);
                    break;
                }
                case R.id.eth_account:
                {
                    setContentView(R.layout.acc_moves_eth);
                    break;
                }
                case R.id.usd_account:
                {
                    setContentView(R.layout.acc_moves_usd);
                    break;
                }
            }
        }
    }
    public void walletOnClick(View view)
    {
        setContentView(R.layout.wallet);
        //link button
        button_euro = (ImageButton) findViewById(R.id.euro_account);
        button_btc = (ImageButton) findViewById(R.id.btc_account);
        Button_eth = (ImageButton) findViewById(R.id.eth_account);
        button_usd = (ImageButton) findViewById(R.id.usd_account);
        //envia al case el click
        button_euro.setOnClickListener(new MainActivity.listWalletMov());
        button_btc.setOnClickListener(new MainActivity.listWalletMov());
        Button_eth.setOnClickListener(new MainActivity.listWalletMov());
        button_usd.setOnClickListener(new MainActivity.listWalletMov());
    }
}